<?php

namespace App\Http\Controllers;

use App\Http\Factories\PaceFactory;
use App\Http\Factories\TournamentFactory;
use App\Http\Requests\StoreTournamentRefereeRequest;
use App\Models\TournamentReferee;
use App\Http\Requests\UpdateTournamentRefereeRequest;
use App\Http\Requests\UpdateTournamentRoundRequest;
use App\Http\Services\GenerateTournamentData;
use App\Http\Services\PaceService;
use App\Imports\GroupImport;
use App\Models\Group;
use App\Models\Hole;
use App\Models\TournamentHole;
use App\Models\TournamentRefereeDuty;
use App\Models\TournamentRound;
use App\Models\User;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class TournamentRoundController extends Controller
{

    /**
     * Display the tournament dashboard.
     */
    public function dashboard($round, Request $request, PaceService $paceService)
    {
        $tournamentRound = TournamentRound::where('id', $round)
            ->with(['groups.players', 'tournament.course', 'tournament.rounds'])
            ->first();

        $tournamentByHole = $paceService->getPacesByHoles($round, $request->input('session', 'morning'));
        $tournamentByTee = $paceService->getPacesByTee($round, $request->input('tee', 1));

        return view('admin.dashboard', [
            'round' => TournamentFactory::dashboard($tournamentRound),
            'holes' => PaceFactory::byHole($tournamentByHole),
            'tees' => PaceFactory::byTee($tournamentByTee),
        ]);
    }

    /**
     * Display the tournament dashboard.
     */
    public function dashboardTable($round, PaceService $paceService)
    {
        $tournamentRound = TournamentRound::where('id', $round)->with(['groups.players', 'tournament.course', 'tournament.rounds'])->first();

        $holes = $paceService->holeType($tournamentRound->tournament->course_id, $round);

        return view('admin.dashboard-table', [
            'round' => TournamentFactory::dashboard($tournamentRound),
            'tee_one' => $holes[1],
            'tee_ten' => $holes[10],
            'paces' => PaceFactory::callWithDetail($paceService->getCurrentTournamentPace($round)),
        ]);
    }

    /**
     * Display the tournament dashboard.
     */
    public function dashboardTablePrint($round, PaceService $paceService)
    {
        $tournamentRound = TournamentRound::where('id', $round)
            ->with(['groups.players', 'tournament.course', 'tournament.rounds'])
            ->first();

        $holes = $paceService->holeType($tournamentRound->tournament->course_id, $round);

        return view('admin.print.dashboard', [
            'round' => TournamentFactory::dashboard($tournamentRound),
            'tee_one' => $holes[1],
            'tee_ten' => $holes[10],
            'paces' => PaceFactory::callWithDetail($paceService->getCurrentTournamentPace($round)),
        ]);
    }

    /**
     * Display the tournament setup page.
     */
    public function setup($round)
    {
        return view('admin.setup', [
            'round' => TournamentFactory::get(TournamentRound::where('id', $round)->where('status', '!=', 'finish')->first()),
        ]);
    }

    /**
     * Display the tournament setup page.
     */
    public function storeSetup($round, UpdateTournamentRoundRequest $request)
    {
        $reqs = $request->only(['tee_area', 'start_interval', 'morning_one', 'morning_ten', 'afternoon_one', 'afternoon_ten', 'crossover_one', 'crossover_ten', 'ball', 'transportation']);
        $reqs['status'] = 'group';

        TournamentRound::where('id', $round)->update($reqs);

        return redirect()->route('round.group', $round);
    }

    /**
     * Display the tournament group page.
     */
    public function group($round, Request $request)
    {
        $request->validate([
            'session' => ['string', 'in:morning,afternoon'],
        ]);

        return view('admin.group', [
            'round' => TournamentFactory::group(TournamentRound::where('id', $round)->where('status', '!=', 'finish')->first(), $request->input('session', 'morning')),
        ]);
    }

    /**
     * Display the tournament group page.
     */
    public function storeGroup($round, Request $request, GenerateTournamentData $generateTournamentData)
    {
        $request->validate([
            'file' => ['required', 'file', 'mimes:xlsx'],
        ]);

        $tournamentRound = TournamentRound::findOrFail($round);

        if ($tournamentRound->status === 'setup') {
            return redirect()->route('round.setup', ['round' => $round])->withErrors(['Error' => 'Cannot import groups for an empty setup tournament round.']);
        }

        if (in_array($tournamentRound->status, ['finish', 'active', 'pause'])) {
            return redirect()->back()->withErrors(['Error' => 'Cannot import groups for a finished, active, or paused tournament round.']);
        }

        if ($tournamentRound->groups->count() > 0) {
            $tournamentRound->groups()->delete();
            $tournamentRound->tournamentPaces()->delete();
        }

        Excel::import(
            new GroupImport(['round_id' => $round]),
            $request->file('file')
        );

        $generateTournamentData->generatePace(
            TournamentRound::where('id', $round)->where('status', '!=', 'finish')->with(['groups.players', 'groups.tournamentPaces', 'tournament.course'])->first()
        );

        $tournamentRound->update(['status' => 'pace']);

        return redirect()->back();
    }

    /**
     * Display the tournament group page.
     */
    public function deleteGroup($round)
    {
        $tournament = TournamentRound::find($round);

        if (in_array($tournament->status, ['finish', 'active', 'pause'])) {
            return redirect()->back()->withErrors(['Error' => 'Cannot delete groups for a finished, active, or paused tournament round.']);
        }

        $tournament->groups()->delete();
        $tournament->update(['status' => 'group']);

        return redirect()->back();
    }

    /**
     * Display the tournament pace page.
     */
    public function pace($round, PaceService $paceService)
    {
        $tournament = TournamentFactory::get(TournamentRound::where('id', $round)->first());

        $holes = $paceService->holeType($tournament->tournament->course_id, $round);

        return view('admin.pace', [
            'round' => $tournament,
            'tee_one' => $holes[1],
            'tee_ten' => $holes[10],
            'paces' => PaceFactory::callWithDetail($paceService->getCurrentTournamentPace($round)),
        ]);
    }

    /**
     * Display the tournament pace page.
     */
    public function pacePrint($round, PaceService $paceService)
    {
        $tournament = TournamentFactory::get(TournamentRound::where('id', $round)->first());

        $holes = $paceService->holeType($tournament->tournament->course_id, $round);

        return view('admin.print.pace', [
            'round' => $tournament,
            'tee_one' => $holes[1],
            'tee_ten' => $holes[10],
            'paces' => PaceFactory::callWithDetail($paceService->getCurrentTournamentPace($round)),
        ]);
    }

    /**
     * Display the tournament referee page.
     */
    public function referee($round)
    {
        return view('admin.referee', [
            'round' => TournamentFactory::get(TournamentRound::where('id', $round)->first()),
            'listRefereeDuties' => TournamentFactory::referee(
                User::with(['groups', 'tournamentHoles'])->whereHas('refereeDuties', function ($query) use ($round) {
                    $query->where('tournament_round_id', $round)
                        ->whereHasMorph('observer', [Group::class, TournamentHole::class]);
                })
                    ->get()
            ),
            'referees' => User::select('id', 'name')->role(['referee', 'observer'])->paginate(10),
            'groups' => Group::where('tournament_round_id', $round)->pluck('name', 'id'),
            'holes' => TournamentHole::whereHas('tournamentPaces', function ($query) use ($round) {
                $query->where('tournament_round_id', $round);
            })->orderBy('number', 'asc')->get(),
        ]);
    }

    /**
     * Display the tournament group page.
     */
    public function storeReferee($round, StoreTournamentRefereeRequest $request)
    {
        $tournamentRound = TournamentRound::findOrFail($round);

        if ($tournamentRound->status !== 'pace' && !in_array($tournamentRound->status, ['finish', 'active', 'pause'])) {
            return redirect()->route('round.setup', ['round' => $round])->withErrors(['Error' => 'Cannot assign referees for a tournament round that is not in referee status.']);
        }

        if (in_array($tournamentRound->status, ['finish', 'active', 'pause'])) {
            return redirect()->back()->withErrors(['Error' => 'Cannot assign referees for a finished, active, or paused tournament round.']);
        }
        
        TournamentRefereeDuty::where('tournament_round_id', $round)->delete();

        $data = [];
        foreach ($request->referees as $referee) {
            foreach ($referee['observer_id'] as $observerId) {
                $data[] = [
                    'tournament_round_id' => $round,
                    'user_id' => $referee['user_id'],
                    'observer_type' => $referee['observer_type'],
                    'observer_id' => $observerId,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }
        }

        $tournamentRound->update(['status' => 'referee']);

        TournamentRefereeDuty::insert($data);

        return redirect()->route('dashboard', ['round' => $round]);
    }

    /**
     * Pause the tournament.
     */
    public function start($round)
    {
        $tournament = TournamentRound::findOrFail($round);

        if ($tournament->status !== 'referee') {
            return redirect()->back()->withErrors(['Error' => 'Cannot start tournament round if the referee is empty.']);
        }

        if (TournamentRound::whereIn('status', ['active', 'pause'])->exists()) {
            return redirect()->back()->withErrors(['Error' => 'Another tournament round is already active.']);
        }

        $tournament->update(['status' => 'active']);

        return redirect()->back();
    }

    /**
     * Stop the tournament.
     */
    public function stop($round)
    {
        $tournament = TournamentRound::findOrFail($round);

        if ($tournament->status !== 'active') {
            return redirect()->back()->withErrors(['Error' => 'Cannot stop tournament round that is not active.']);
        }

        $tournament->update(['status' => 'finish']);

        return redirect()->back();
    }

    /**
     * Pause the tournament.
     */
    public function pause($round)
    {
        $tournament = TournamentRound::findOrFail($round);

        if ($tournament->status !== 'active') {
            return redirect()->back()->withErrors(['Error' => 'Cannot pause tournament round that is not active.']);
        }

        $tournament->update(['status' => 'pause']);

        return redirect()->back();
    }

    /**
     * Resume the tournament.
     */
    public function resume($round)
    {
        $tournament = TournamentRound::findOrFail($round);

        if ($tournament->status !== 'pause') {
            return redirect()->back()->withErrors(['Error' => 'Cannot resume tournament round that is not paused.']);
        }

        $tournament->update(['status' => 'active']);

        return redirect()->back();
    }
}
