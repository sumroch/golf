<?php

namespace App\Http\Controllers;

use App\Models\TournamentPace;
use App\Http\Requests\StoreTournamentPaceRequest;
use App\Http\Requests\UpdateTournamentPaceRequest;

class TournamentPaceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTournamentPaceRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(TournamentPace $tournamentPace)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(TournamentPace $tournamentPace)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTournamentPaceRequest $request, TournamentPace $tournamentPace)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TournamentPace $tournamentPace)
    {
        //
    }
}
